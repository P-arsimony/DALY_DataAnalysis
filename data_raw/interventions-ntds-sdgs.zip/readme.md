# Number of people requiring treatment against neglected tropical diseases - Data package

This data package contains the data that powers the chart ["Number of people requiring treatment against neglected tropical diseases"](https://ourworldindata.org/grapher/interventions-ntds-sdgs?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on February 12, 2026.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For most countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Reported number of people requiring interventions against NTDs
Number of people requiring treatment and care for any one of the neglected tropical diseases (NTDs) targeted by the WHO NTD Roadmap and World Health Assembly resolutions and reported to WHO.
Last updated: May 19, 2025  
Next update: May 2026  
Date range: 2010–2023  
Unit: Number of people  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
World Health Organization - Global Health Observatory (2025) – processed by Our World in Data

#### Full citation
World Health Organization - Global Health Observatory (2025) – processed by Our World in Data. “Reported number of people requiring interventions against NTDs” [dataset]. World Health Organization, “Global Health Observatory” [original data].
Source: World Health Organization - Global Health Observatory (2025) – processed by Our World In Data

### How is this data described by its producer - World Health Organization - Global Health Observatory (2025)?
#### Rationale
The average annual number of people requiring treatment and care for NTDs is the number that is expected to decrease toward “the end of NTDs” by 2030 (target 3.3), as NTDs are eradicated, eliminated or controlled. The number of people requiring other interventions against NTDs (e.g. vector management, veterinary public health, water, sanitation and hygiene) are expected to need to be maintained beyond 2030 and are therefore to be addressed in the context of other targets and indicators, namely Universal Health Coverage (UHC) and universal access to water and sanitation. This number should not be interpreted as the number of people at risk for NTDs. It is in fact a subset of the larger number of people at risk. Mass treatment is limited to those living in districts above a threshold level of prevalence; it does not include all people living in districts with any risk of infection. Individual treatment and care is for those who are or have already been infected; it does not include all contacts and others at risk of infection. This number can better be interpreted as the number of people at a level of risk requiring medical intervention – that is, treatment and care for NTDs.

#### Definition
Number of people requiring treatment and care for any one of the neglected tropical diseases (NTDs) targeted by the WHO NTD Roadmap and World Health Assembly resolutions and reported to WHO.

#### Method of estimation
Some estimation is required to aggregate data across interventions and diseases. There is an established methodology that has been tested and an agreed international standard. https://apps.who.int/iris/bitstream/handle/10665/241869/WER8702.PDF 

1) Average annual number of people requiring mass treatment known as PC for at least one PC-NTD (lymphatic filariasis, onchocerciasis, schistosomiasis, soil-transmitted helminthiases and trachoma). People may require PC for more than one PC-NTD. The number of people requiring PC is compared across the PC-NTDs, by age group and implementation unit (e.g. district). The largest number of people requiring PC is retained for each age group in each implementation unit. The total is considered to be a conservative estimate of the number of people requiring PC for at least one PC-NTD. Prevalence surveys determine when an NTD has been eliminated or controlled and PC can be stopped or reduced in frequency, such that the average annual number of people requiring PC is reduced. 2) Number of new cases requiring individual treatment and care for other NTDs: The number of new cases is based on country reports, whenever available, of new and known cases of Buruli ulcer, dengue, dracunculiasis, echinococcosis, human African trypanosomiasis (HAT), leprosy, the leishmaniases, rabies and yaws. Where the number of people requiring and requesting surgery for PC-NTDs (e.g. trichiasis or hydrocele surgery) is reported, it can be added here. Similarly, new cases requiring and requesting rehabilitation (e.g. leprosy or lymphoedema) can be added whenever available. Populations referred to under 1) and 2) may overlap; the sum would overestimate the total number of people requiring treatment and care. The maximum of 1) or 2) is therefore retained at the lowest common implementation unit and summed to get conservative country, regional and global aggregates. By 2030, improved co-endemicity data and models will validate the trends obtained using this simplified approach.

### Source

#### World Health Organization – Global Health Observatory
Retrieved on: 2025-05-19  
Retrieved from: https://www.who.int/data/gho  


    