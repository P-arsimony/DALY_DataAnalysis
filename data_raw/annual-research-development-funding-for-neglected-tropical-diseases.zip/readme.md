# Annual research & development funding for infectious diseases - Data package

This data package contains the data that powers the chart ["Annual research & development funding for infectious diseases"](https://ourworldindata.org/grapher/annual-research-development-funding-for-neglected-tropical-diseases?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website.

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For most countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The remaining columns are the data columns, each of which is a time series. If the CSV data is downloaded using the "full data" option, then each column corresponds to one time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data columns are transformed depending on the chart type and thus the association with the time series might not be as straightforward.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

### How we process data at Our World In Data
All data and visualizations on Our World in Data rely on data sourced from one or several original data providers. Preparing this original data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/)

## Detailed information about each time series


## Buruli ulcer
The amount of funding for buruli ulcer. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Buruli ulcer” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Chagas disease
The amount of funding for kinetoplastid diseases - chagas' disease. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Chagas disease” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Dengue
The amount of funding for dengue. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Dengue” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Chikungunya
The amount of funding for chikungunya. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2018–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Chikungunya” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Hookworm
The amount of funding for helminth infections (worms & flukes) - hookworm (ancylostomiasis & necatoriasis). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Hookworm” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Roundworm
The amount of funding for helminth infections (worms & flukes) - roundworm (ascariasis). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Roundworm” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Whipworm
The amount of funding for helminth infections (worms & flukes) - whipworm (trichuriasis). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Whipworm” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Tapeworm
The amount of funding for helminth infections (worms & flukes) - tapeworm (taeniasis / cysticercosis). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Tapeworm” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Schistosomiasis
The amount of funding for helminth infections (worms & flukes) - schistosomiasis (bilharziasis). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Schistosomiasis” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## River blindness
The amount of funding for helminth infections (worms & flukes) - onchocerciasis (river blindness). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “River blindness” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Lymphatic filariasis
The amount of funding for helminth infections (worms & flukes) - lymphatic filariasis (elephantiasis). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Lymphatic filariasis” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Leishmaniasis
The amount of funding for kinetoplastid diseases - leishmaniasis. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Leishmaniasis” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Leprosy
The amount of funding for leprosy. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Leprosy” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Mycetoma
The amount of funding for mycetoma. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2018–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Mycetoma” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Scabies
The amount of funding for scabies. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2020–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Scabies” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Snakebite envenoming
The amount of funding for snakebite envenoming. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2018–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Snakebite envenoming” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Trachoma
The amount of funding for trachoma. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2022  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Trachoma” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Malaria
The amount of funding for malaria - all types. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Malaria” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## Tuberculosis
The amount of funding for tuberculosis. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “Tuberculosis” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## HIV/AIDS
The amount of funding for hiv/aids. This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2007–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “HIV/AIDS” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


## COVID-19
The amount of funding for coronaviral diseases (including mers, sars, covid-19) - coronavirus disease 2019 (covid-19). This data is expressed in US dollars, adjusted for inflation.
Last updated: August 20, 2025  
Next update: August 2026  
Date range: 2020–2023  
Unit: constant 2022 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Impact Global Health (2024) – with major processing by Our World in Data

#### Full citation
Impact Global Health (2024) – with major processing by Our World in Data. “COVID-19” [dataset]. Impact Global Health, “G-FINDER” [original data].
Source: Impact Global Health (2024) – with major processing by Our World In Data

### Source

#### Impact Global Health – G-FINDER
Retrieved on: 2025-08-20  
Retrieved from: https://gfinderdata.impactglobalhealth.org/pages/data-visualisations/allNeglectedDiseases  


    